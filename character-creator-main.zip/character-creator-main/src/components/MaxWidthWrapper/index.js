export { default } from './MaxWidthWrapper';
