export { default } from './Character';
